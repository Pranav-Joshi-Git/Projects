# App-Subscription-Analysis

Internship Project

 1. Graphs - complete EDA (Exploratory data analysis)
 2. ASA (PPT) - Powerpoint presentation of the projects.
 3. ASA (jupyter notebook) - python code.
 4. ASA documentation - Documentation of the projects.
 5. data.csv - CSV file of dataset.
